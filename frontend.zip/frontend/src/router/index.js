import { createRouter, createWebHistory } from 'vue-router'
import Salas from '../views/Salas.vue'

const routes = [
  /*{
    path: '/',
    name: 'Dashboard',
    component: Dashboard
  },
  {
    path: '/sensors',
    name: 'Sensors',
    component: Sensors
  },
  {
    path: '/alerts',
    name: 'Alerts',
    component: Alerts
  },
  {
    path: '/settings',
    name: 'Settings',
    component: Settings
  },*/
  {
    path: '/salas',
    name: 'Salas',
    component: Salas
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router 