<template>
    <div class="view-settings">
      <h1>Salas</h1>
      <p>Salas de la escuela.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Salas'
  }
  </script>
  
  <style scoped>
  .view-settings {
    padding: 16px;
  }
  </style>
  