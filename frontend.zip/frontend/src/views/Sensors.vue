<template>
    <div class="view-sensors">
      <h1>Sensores</h1>
      <p>Listado y estado de sensores (simulado).</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Sensors'
  }
  </script>
  
  <style scoped>
  .view-sensors {
    padding: 16px;
  }
  </style>
  