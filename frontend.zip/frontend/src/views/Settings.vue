<template>
    <div class="view-settings">
      <h1>Configuración</h1>
      <p>Ajustes del sistema.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Settings'
  }
  </script>
  
  <style scoped>
  .view-settings {
    padding: 16px;
  }
  </style>
  