<template>
    <div class="view-dashboard">
      <h1>Dashboard</h1>
      <p>Bienvenido al panel de control.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Dashboard'
  }
  </script>
  
  <style scoped>
  .view-dashboard {
    padding: 16px;
  }
  </style>
  