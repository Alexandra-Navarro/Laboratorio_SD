<template>
  <v-app>
    <v-navigation-drawer v-model="drawer" app>
      <v-list>
        <v-list-group
          :value="true"
          prepend-icon="mdi-home-city"
        >
          <template v-slot:activator="{ props }">
            <v-list-item
              v-bind="props"
              title="Salas"
            ></v-list-item>
          </template>

          <!-- Mostrar loading mientras se cargan las salas -->
          <v-list-item v-if="loading" class="ml-4">
            <v-list-item-icon>
              <v-progress-circular
                indeterminate
                size="20"
                color="primary"
              ></v-progress-circular>
            </v-list-item-icon>
            <v-list-item-content>
              <v-list-item-title>Cargando salas...</v-list-item-title>
            </v-list-item-content>
          </v-list-item>

          <!-- Mostrar error si hay problemas -->
          <v-list-item v-else-if="error" class="ml-4">
            <v-list-item-icon>
              <v-icon color="error">mdi-alert-circle</v-icon>
            </v-list-item-icon>
            <v-list-item-content>
              <v-list-item-title class="text-error">{{ error }}</v-list-item-title>
            </v-list-item-content>
          </v-list-item>

          <!-- Mostrar salas obtenidas de la API -->
          <v-list-item
            v-else
            v-for="sala in salas"
            :key="sala.id"
            :to="sala.path"
            link
            class="ml-4"
          >
            <v-list-item-icon>
              <v-icon>{{ sala.icon }}</v-icon>
            </v-list-item-icon>
            <v-list-item-content>
              <v-list-item-title>{{ sala.nombre }}</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list-group>
      </v-list>
    </v-navigation-drawer>

    <v-app-bar app color="primary" dark>
      <v-app-bar-nav-icon @click="drawer = !drawer"></v-app-bar-nav-icon>
      <v-toolbar-title>Sistema de Monitoreo Ambiental</v-toolbar-title>
    </v-app-bar>

    <v-main>
      <v-container fluid>
        <router-view></router-view>
      </v-container>
    </v-main>
  </v-app>
</template>

<script>
import axios from 'axios'

export default {
  name: 'App',
  data: () => ({
    drawer: true,
    salas: [],
    loading: false,
    error: null
  }),
  async created() {
    await this.obtenerSalas()
  },
  methods: {
    async obtenerSalas() {
      try {
        this.loading = true
        this.error = null
        const response = await axios.get('http://localhost:8080/api/salas')
        
        console.log('Respuesta de la API:', response.data) // Para debug
        
        // La API devuelve un array directo, no necesita mapeo adicional
        if (!Array.isArray(response.data)) {
          throw new Error('La respuesta de la API no es un array válido')
        }
        
        // Mapear las salas obtenidas de la API
        this.salas = response.data.map(sala => ({
          id: sala.id,
          nombre: sala.nombre,
          icon: this.obtenerIconoPorEscuela(sala.escuela_id),
          path: `/salas/${sala.id}`
        }))
      } catch (error) {
        console.error('Error al obtener salas:', error)
        this.error = 'No se pudieron cargar las salas'
        // Salas de respaldo en caso de error
        this.salas = [
          {
            id: 1,
            nombre: 'Sala por defecto',
            icon: 'mdi-home-city',
            path: '/salas/1'
          }
        ]
      } finally {
        this.loading = false
      }
    },
    obtenerIconoPorEscuela(escuela_id) {
      // Puedes personalizar los iconos por escuela o usar uno general
      const iconos = {
        1: 'mdi-school', // Escuela 1
        2: 'mdi-book-open-variant', // Escuela 2  
        3: 'mdi-account-group', // Escuela 3
        'default': 'mdi-door'
      }
      return iconos[escuela_id] || iconos.default
    }
  }
}
</script>

<style>
@import '@mdi/font/css/materialdesignicons.css';
</style>